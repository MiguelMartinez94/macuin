<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MACUIN — Panel de Accesos</title>
    <link rel="stylesheet" href="<?php echo e(asset('resources/css/styles.css')); ?>">
</head>
<body>

    <header>
        <a href="/dashboard" class="logo-link">MACUIN</a>
        <nav>
            <a href="/dashboard">INICIO</a>
            <a href="/productos/nuevo">NUEVO PRODUCTO</a>
            <a href="/compras">COMPRAS</a>
            <a href="/panel-accesos">PANEL DE ACCESOS</a>
            <button class="btn-red" onclick="window.location.href='/logout'">CERRAR SESIÓN</button>
        </nav>
    </header>

    <div class="main-wrap">
        <h1>PANEL DE ACCESOS</h1>
        <p class="tagline">Usuarios y permisos del sistema administrativo Macuin.</p>

        <div style="display: flex; justify-content: flex-end; margin-bottom: 30px;">
            <a href="/personal" style="background:#F5C518; color:#111; font-weight:900; font-size:12px; text-transform:uppercase; letter-spacing:1px; padding:12px 24px; border-radius:8px; text-decoration:none;">
                + GESTIÓN DE PERSONAL
            </a>
        </div>

        <?php if(session('success')): ?>
            <div style="background: rgba(34,197,94,0.2); border: 2px solid #22c55e; color: #4ade80; padding: 12px; border-radius: 10px; margin-bottom: 30px; text-align: center; font-weight: 800; text-transform:uppercase; font-size:12px; letter-spacing:1px;">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <?php if(session('error')): ?>
            <div style="background: rgba(239,68,68,0.15); border: 2px solid #ef4444; color: #f87171; padding: 12px; border-radius: 10px; margin-bottom: 30px; text-align: center; font-weight: 800; text-transform:uppercase; font-size:12px; letter-spacing:1px;">
                <?php echo e(session('error')); ?>

            </div>
        <?php endif; ?>

        <table class="panel-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>NOMBRE DEL EMPLEADO</th>
                    <th>EMAIL INSTITUCIONAL</th>
                    <th>ROL</th>
                    <th style="text-align: right;">ACCIÓN</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td style="color:#aaa;">#<?php echo e($u['id']); ?></td>
                    <td style="text-transform:uppercase;"><?php echo e($u['nombre']); ?></td>
                    <td><?php echo e($u['email']); ?></td>
                    <td><span class="badge-role"><?php echo e(strtoupper($u['role'])); ?></span></td>
                    <td style="text-align: right;">
                        <form action="/admins/borrar/<?php echo e($u['id']); ?>" method="POST" onsubmit="return confirm('¿Dar de baja definitivamente?')">
                            <?php echo csrf_field(); ?>
                            <button type="submit" style="background:#111; color:#fff; border:none; padding:10px 20px; border-radius:8px; font-weight:900; font-size:10px; cursor:pointer; text-transform:uppercase;">DAR DE BAJA</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="5" style="text-align:center; padding:60px; color:#888;">SIN USUARIOS REGISTRADOS</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

</body>
</html>
<?php /**PATH /app/resources/views/empleados/panel_accesos.blade.php ENDPATH**/ ?>