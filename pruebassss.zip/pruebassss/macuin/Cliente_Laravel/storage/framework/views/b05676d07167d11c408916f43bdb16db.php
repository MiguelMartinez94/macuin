<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Macuin - Registro / Login</title>
    <!-- Se asume que el CSS en Laravel está en /css/styles.css o similar al que usan otras vistas -->
    <link rel="stylesheet" href="<?php echo e(asset('public/resources/css/styles.css')); ?>" />
    </head>

    <body class="registro">

    <article>


        <div>
        <h1>Macuin (Administrador)</h1>
        <?php if(session('error')): ?>
            <ul style="color:red; list-style:none; padding:0;">
                <li><?php echo e(session('error')); ?></li>
            </ul>
        <?php endif; ?>
        </div>

        <form action="/login" method="POST">
        <?php echo csrf_field(); ?>
        <div>
            <div>
            <label>Correo Electrónico</label>
            <div>
                <input type="email" name="email" placeholder="admin@macuin.com" required/>
            </div>
            </div>
        </div>

        <div>
            <div>
            <label>Contraseña</label>
            <div>
                <input type="password" name="password" required/>
            </div>
            </div>
            <div>
            <label>Confirmar Contraseña</label>
            <div>
                <input type="password"/>
            </div>
            </div>
        </div>

        <button type="submit">Registrarse</button>
        </form>

        <footer>
        <p>¿Ya tienes cuenta? <a href="/productos">Inicia Sesión</a></p>
        </footer>

    </article>

</body>
</html>
<?php /**PATH /app/resources/views/login.blade.php ENDPATH**/ ?>